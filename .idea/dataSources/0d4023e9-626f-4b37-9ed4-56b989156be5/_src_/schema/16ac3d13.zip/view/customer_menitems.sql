CREATE VIEW `customer_menitems` AS
  SELECT
    `16ac3d13`.`differentitem`.`Id`          AS `Id`,
    `16ac3d13`.`differentitem`.`Description` AS `Description`,
    `16ac3d13`.`differentitem`.`Brand`       AS `Brand`,
    `16ac3d13`.`differentitem`.`Price`       AS `Price`,
    `16ac3d13`.`differentitem`.`ImagePath`   AS `ImagePath`,
    `16ac3d13`.`apparelattribute`.`Size`     AS `Size`,
    `16ac3d13`.`apparelattribute`.`Color`    AS `Color`,
    `16ac3d13`.`apparelattribute`.`ForMen`   AS `ForMen`
  FROM (`16ac3d13`.`differentitem`
    JOIN `16ac3d13`.`apparelattribute` ON ((`16ac3d13`.`differentitem`.`Id` = `16ac3d13`.`apparelattribute`.`Id`)))
  WHERE (((`16ac3d13`.`differentitem`.`AvailableOnline` = 1) AND (`16ac3d13`.`apparelattribute`.`ForMen` = 1)) OR
         isnull(`16ac3d13`.`apparelattribute`.`ForMen`))