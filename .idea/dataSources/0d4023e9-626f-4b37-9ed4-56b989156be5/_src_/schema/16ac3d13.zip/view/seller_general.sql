CREATE VIEW `seller_general` AS
  SELECT
    `16ac3d13`.`differentitem`.`Price`       AS `Price`,
    `16ac3d13`.`differentitem`.`Id`          AS `Id`,
    `16ac3d13`.`differentitem`.`Description` AS `Description`,
    `16ac3d13`.`differentitem`.`Brand`       AS `Brand`,
    `16ac3d13`.`differentitem`.`ImagePath`   AS `ImagePath`
  FROM `16ac3d13`.`differentitem`
  WHERE (`16ac3d13`.`differentitem`.`Category` = 'general')