CREATE PROCEDURE `updateProfileStaffProcedure`(`firstname`     VARCHAR(50), `lastname` VARCHAR(50),
                                               `contactnumber` VARCHAR(15), `email` VARCHAR(50), `username` VARCHAR(45),
                                               `password`      VARCHAR(45), `targetId` SMALLINT(6))
  BEGIN
	 UPDATE staff SET FirstName = firstname, LastName=lastname, ContactNumber=contactnumber, Email=email, UserName=username, Password=password WHERE Id=targetId;
END