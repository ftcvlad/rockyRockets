CREATE PROCEDURE `deleteStaffProcedure`(`idToDelete` SMALLINT(6))
  BEGIN
	DELETE FROM staff WHERE Id=idToDelete;
END