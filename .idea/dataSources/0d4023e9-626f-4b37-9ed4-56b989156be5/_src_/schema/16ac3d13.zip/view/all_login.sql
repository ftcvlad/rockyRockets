CREATE VIEW `all_login` AS
  SELECT
    `16ac3d13`.`staff`.`UserName`                  AS `UserName`,
    `16ac3d13`.`staff`.`Password`                  AS `Password`,
    `16ac3d13`.`staff`.`Position`                  AS `Position`,
    `16ac3d13`.`staff_department`.`DepartmentType` AS `DepartmentType`,
    `16ac3d13`.`staff_department`.`LocationId`     AS `LocationId`,
    `16ac3d13`.`staff`.`Id`                        AS `Id`
  FROM (`16ac3d13`.`staff`
    LEFT JOIN `16ac3d13`.`staff_department`
      ON ((`16ac3d13`.`staff_department`.`Id` = `16ac3d13`.`staff`.`DepartmentId`)))