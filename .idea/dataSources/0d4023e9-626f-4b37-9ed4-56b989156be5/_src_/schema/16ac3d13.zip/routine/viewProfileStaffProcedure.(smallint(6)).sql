CREATE PROCEDURE `viewProfileStaffProcedure`(`targetId` SMALLINT(6))
  BEGIN
       	SELECT  FirstName, LastName, ContactNumber, Email, UserName,DOB,Position,Salary, Password FROM staff WHERE Id =targetId;
END