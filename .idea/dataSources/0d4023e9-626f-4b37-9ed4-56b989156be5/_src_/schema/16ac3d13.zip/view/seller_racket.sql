CREATE VIEW `seller_racket` AS
  SELECT
    `16ac3d13`.`differentitem`.`Id`          AS `itemId`,
    `16ac3d13`.`differentitem`.`Price`       AS `Price`,
    `16ac3d13`.`differentitem`.`Brand`       AS `Brand`,
    `16ac3d13`.`differentitem`.`Description` AS `Description`,
    `16ac3d13`.`differentitem`.`ImagePath`   AS `ImagePath`,
    `16ac3d13`.`racketattribute`.`Sport`     AS `Sport`,
    `16ac3d13`.`racketattribute`.`Weight`    AS `Weight`,
    `16ac3d13`.`racketattribute`.`Balance`   AS `Balance`
  FROM (`16ac3d13`.`differentitem`
    JOIN `16ac3d13`.`racketattribute` ON ((`16ac3d13`.`differentitem`.`Id` = `16ac3d13`.`racketattribute`.`Id`)))