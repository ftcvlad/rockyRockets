CREATE PROCEDURE `purchaseItems`(`item_id_array` VARCHAR(255), `quant_array` VARCHAR(255), `customer_ID` INT(11))
  BEGIN

DECLARE purchaseID int;
DECLARE locationId tinyint;
DECLARE nextItemId  int;
DECLARE nextQuantity smallint;

/*update purchase*/
Insert Into purchase (Date, CustomerID) VALUES (NOW(), customer_ID);
SET purchaseID = LAST_INSERT_ID();


WHILE (LOCATE(',', item_id_array) > 0)
DO
    SET nextItemId = cast(SUBSTRING_INDEX(item_id_array, ",", 1) AS UNSIGNED);
    SET item_id_array= SUBSTRING(item_id_array, LOCATE(',',item_id_array)+1);
    
    SET nextQuantity = cast(SUBSTRING_INDEX(quant_array, ",", 1) AS UNSIGNED);
    SET quant_array= SUBSTRING(quant_array, LOCATE(',',quant_array) + 1);

   
    /*update location_has_differentitem*/
	set locationId = (select Location_Id 
	from location_has_differentitem
	where ItemKind_Id=nextItemId AND Quantity = 
			(select max(quantity) from location_has_differentitem where ItemKind_Id=nextItemId) LIMIT 1);

	UPDATE location_has_differentitem
	SET Quantity=Quantity-nextQuantity
	WHERE ItemKind_Id=nextItemId AND Location_Id=locationId;

	/*update purchase_has_differentitem*/
	INSERT INTO purchase_has_differentitem (Quantity, ItemId, PurchaseId)
	VALUES (nextQuantity, nextItemId, purchaseID);
   
   
END WHILE;



END