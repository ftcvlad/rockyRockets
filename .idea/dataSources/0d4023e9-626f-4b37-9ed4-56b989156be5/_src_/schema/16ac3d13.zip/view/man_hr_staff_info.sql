CREATE VIEW `man_hr_staff_info` AS
  SELECT
    `16ac3d13`.`staff`.`FirstName`                 AS `FirstName`,
    `16ac3d13`.`staff`.`LastName`                  AS `LastName`,
    `16ac3d13`.`staff`.`ContactNumber`             AS `ContactNumber`,
    `16ac3d13`.`staff`.`Position`                  AS `Position`,
    `16ac3d13`.`staff`.`Salary`                    AS `Salary`,
    `16ac3d13`.`staff`.`Id`                        AS `Id`,
    `16ac3d13`.`staff`.`DOB`                       AS `DOB`,
    `16ac3d13`.`location`.`AddressLine1`           AS `AddressLine1`,
    `16ac3d13`.`location`.`Street`                 AS `Street`,
    `16ac3d13`.`location`.`City`                   AS `City`,
    `16ac3d13`.`location`.`PostCode`               AS `PostCode`,
    `16ac3d13`.`staff_department`.`DepartmentType` AS `DepartmentType`,
    `16ac3d13`.`staff`.`DepartmentId`              AS `DepartmentId`,
    `16ac3d13`.`staff`.`UserName`                  AS `UserName`,
    `16ac3d13`.`staff`.`Password`                  AS `Password`,
    `16ac3d13`.`location`.`LocationType`           AS `LocationType`
  FROM ((`16ac3d13`.`staff`
    JOIN `16ac3d13`.`staff_department`
      ON ((`16ac3d13`.`staff_department`.`Id` = `16ac3d13`.`staff`.`DepartmentId`))) JOIN `16ac3d13`.`location`
      ON ((`16ac3d13`.`location`.`Id` = `16ac3d13`.`staff_department`.`LocationId`)))