CREATE VIEW `seller_item_location` AS
  SELECT
    `16ac3d13`.`location_has_differentitem`.`Quantity`    AS `Quantity`,
    `16ac3d13`.`location_has_differentitem`.`ItemKind_Id` AS `ItemKind_Id`,
    `16ac3d13`.`location_has_differentitem`.`Location_Id` AS `Location_Id`,
    `16ac3d13`.`location`.`AddressLine1`                  AS `AddressLine1`,
    `16ac3d13`.`location`.`Street`                        AS `Street`,
    `16ac3d13`.`location`.`LocationType`                  AS `LocationType`,
    `16ac3d13`.`location`.`City`                          AS `City`,
    `16ac3d13`.`location`.`PostCode`                      AS `PostCode`
  FROM (`16ac3d13`.`location_has_differentitem`
    LEFT JOIN `16ac3d13`.`location`
      ON ((`16ac3d13`.`location`.`Id` = `16ac3d13`.`location_has_differentitem`.`Location_Id`)))
  WHERE (`16ac3d13`.`location`.`LocationType` = 'Shop')