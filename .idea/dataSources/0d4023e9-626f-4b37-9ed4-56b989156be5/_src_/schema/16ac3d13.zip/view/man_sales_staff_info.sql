CREATE VIEW `man_sales_staff_info` AS
  SELECT
    `16ac3d13`.`staff`.`FirstName`                 AS `FirstName`,
    `16ac3d13`.`staff`.`LastName`                  AS `LastName`,
    `16ac3d13`.`staff`.`ContactNumber`             AS `ContactNumber`,
    `16ac3d13`.`staff`.`Position`                  AS `Position`,
    `16ac3d13`.`staff_department`.`PhoneNumber`    AS `DepartmentPhoneNumber`,
    `16ac3d13`.`staff_department`.`DepartmentType` AS `DepartmentType`,
    `16ac3d13`.`location`.`LocationType`           AS `LocationType`,
    `16ac3d13`.`location`.`AddressLine1`           AS `AddressLine1`,
    `16ac3d13`.`location`.`Street`                 AS `Street`,
    `16ac3d13`.`location`.`City`                   AS `City`,
    `16ac3d13`.`location`.`PostCode`               AS `PostCode`
  FROM ((`16ac3d13`.`staff`
    JOIN `16ac3d13`.`staff_department`
      ON ((`16ac3d13`.`staff_department`.`Id` = `16ac3d13`.`staff`.`DepartmentId`))) JOIN `16ac3d13`.`location`
      ON ((`16ac3d13`.`location`.`Id` = `16ac3d13`.`staff_department`.`LocationId`)))